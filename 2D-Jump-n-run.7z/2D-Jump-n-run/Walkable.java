import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Walkable extends Actor
{
   public void act()
   {
    
   }
}