import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class word here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class world extends World
{
    public static final int xRes = 720; //nicht vor konstruktor verfügbar - fix public static final
    public static final int yRes = 480; 
    public static final int clusterSize = 1;
    public world()
    {    
        super(xRes, yRes, clusterSize);
    }
}
