import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Fallable
{
    private int xSpeed = 4; //also halt geschwindingkeit
    private int jumpCount = 0;
    private int playerState = 1;
    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkFall();
        locomotion();
        galaxyNote7();
        endGame();
    }
    public void locomotion()
    {
        if (Greenfoot.isKeyDown("D"))
        {
            move(xSpeed);
        }
        if (Greenfoot.isKeyDown("A"))
        {
            move(-xSpeed);
        }
        if (Greenfoot.isKeyDown("Space") && onGround()) //doppelsprung bug - fix mit && onGround() 19.06.25
        {
            vSpeed = -15;
            fall();
            jumpCount = jumpCount + 1;
            }
        if (Greenfoot.isKeyDown("shift"))
        {
            xSpeed = 6;
        }
        
        else
        {
            xSpeed = 4;
        }
    }
    private void galaxyNote7()
    {
        if (getY() >= getWorld().getHeight() - 1) // -1, weil die Koordinaten bei 0 beginnen
        {
            playerState = 0;
        }
    }
    public int getJumpCount()
    {
        return jumpCount;
    }
    public int getPlayerState()
    {
        return playerState;
    }
    public void endGame()
    {
        if (playerState == 0)
        {
            Greenfoot.stop ();
            playerState = 1;
        }
    }
}