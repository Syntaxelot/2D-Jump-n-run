    import greenfoot.*;

/**
 * Simple gravitation added
 * 16.06.2025
 * Syntaxelot 
 * v.0.1
 */
public class Fallable extends Actor
{
    protected int vSpeed = 1;
    protected int acceleration = 1;
    public boolean onGround()
    {
        Object under = getOneObjectAtOffset(0, getImage().getHeight()/2 + 2, Walkable.class); //ingnoriert Block  Brick - fix durch walkable statt ground
        return under != null;
    }
    public void fall()
    {
        setLocation (getX(), getY() + vSpeed);
        vSpeed += acceleration;
    }
    public void checkFall()
    {
        if (onGround()) {
            vSpeed = 0;
        }
        else {
            fall();
        }
    }
}
